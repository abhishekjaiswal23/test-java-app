package com.lapx.project.lapx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LapxApplication {

	public static void main(String[] args) {
		SpringApplication.run(LapxApplication.class, args);
	}

}
